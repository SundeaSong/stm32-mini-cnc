#include "StepMotor.h"


char StepMotor_Home(StepMotor *stepmotor)
{
    char dir = stepmotor->HomeDIR;
    Star:    
    //判断方向
    switch (stepmotor->Axis)
    {
        case 0:
            dir ==0?Y9_ON:Y9_OFF;
            break;
        case 1:
            dir ==0?Y11_ON:Y11_OFF;
            break;
        case 2:
            dir ==0?Y13_ON:Y13_OFF;
            break;
        case 3:
            dir ==0?Y15_ON:Y15_OFF;
            break;
        default:
            break;
    }
    
    Delay_US(5);
    //发送脉冲
    while(1)
    {   
//        //极限判断
//        if((X21==ON)||(X23==ON)||(X25==ON)||(X27==ON)) 
//        {
//            stepmotor.HomeDIR = 1;
//            goto Star;
//        }
//        if((X22==ON)||(X24==ON)||(X26==ON)||(X28==ON)) 
//        {
//            stepmotor.HomeDIR = 0;
//            goto Star;
//        }
//        //原点判断
//        if((X29==ON)||(X30==ON)||(X31==ON)||(X32==ON)) 
//        {
//            stepmotor.Position = 0;
//            stepmotor.HomeDIR = 0;
//            return 0;
//        }
        switch (stepmotor->Axis)
        {
            case 0:
                if((X21==ON)&&(dir == 0))
                {
                    dir = 1;
                    goto Star;
                }
                if((X22==ON)&&(dir == 1)) 
                {
                    dir = 0;
                    goto Star;
                }
                if(X29==ON)
                {
                    stepmotor->Position = 0;
                    return 0;
                }
                break;
            case 1:
                if((X23==ON)&&(dir == 0))
                {
                    dir = 1;
                    goto Star;
                }
                if((X24==ON)&&(dir == 1)) 
                {
                    dir = 0;
                    goto Star;
                }
                if(X30==ON)
                {
                    stepmotor->Position = 0;
                    return 0;
                }
                break;
            case 2:
                if((X25==ON)&&(dir == 0)) 
                {
                    dir = 1;
                    goto Star;
                }
                if((X26==ON)&&(dir == 1)) 
                {
                    dir = 0;
                    goto Star;
                }
                if(X31==ON)
                {
                    stepmotor->Position = 0;
                    return 0;
                }
                break;
            case 3:
                if((X27==ON)&&(dir == 0)) 
                {
                    dir = 1;
                    goto Star;
                }
                if((X28==ON)&&(dir == 1)) 
                {
                    dir = 0;
                    goto Star;
                }
                if(X32==ON)
                {
                    stepmotor->Position = 0;
                    return 0;
                }
                break;
            default:
                break;
        }
        
        switch (stepmotor->Axis)
        {
            case 0:
                Y10_ON;
                break;
            case 1:
                Y12_ON;
                break;
            case 2:
                Y14_ON;
                break;
            case 3:
                Y16_ON;
                break;
            default:
                break;
        }
        Delay_US(1);
        switch (stepmotor->Axis)
        {
            case 0:
                Y10_OFF;
                break;
            case 1:
                Y12_OFF;
                break;
            case 2:
                Y14_OFF;
                break;
            case 3:
                Y16_OFF;
                break;
            default:
                break;
        }
        Delay_US(80);
    }   
    
}


// Header: 步进电机定点控制，相对运动，输入轴号(0-3),运动方向，脉冲数，
//         输出0，正常，1 正极限，2 负极限
// File Name: 
// Author:
// Date:
char StepMotor_Control(StepMotor *stepmotor,unsigned char dir,unsigned int Plus)
{
    unsigned int step;
    
    //判断方向
    switch (stepmotor->Axis)
    {
        case 0:
            dir ==0?Y9_ON:Y9_OFF;
            break;
        case 1:
            dir ==0?Y11_ON:Y11_OFF;
            break;
        case 2:
            dir ==0?Y13_ON:Y13_OFF;
            break;
        case 3:
            dir ==0?Y15_ON:Y15_OFF;
            break;
        default:
            break;
    }
    
    Delay_US(5);
    //发送脉冲
    for(step=0;step<Plus;step++)
    {   
        //极限判断
//        if((X25==ON)||(X27==ON)||(X29==ON)||(X31==ON)) return 1;
//        if((X26==ON)||(X28==ON)||(X30==ON)||(X32==ON)) return 2;
        switch (stepmotor->Axis)
        {
            case 0:
                if(X21==ON)
                {
                    return 1;
                }
                if(X22==ON)
                {
                    return 2;
                }
                break;
            case 1:
                if(X23==ON)
                {
                    return 1;
                }
                if(X24==ON)
                {
                    return 2;
                }
                break;
            case 2:
                if(X25==ON)
                {
                    return 1;
                }
                if(X26==ON)
                {
                    return 2;
                }
                break;
            case 3:
                if(X27==ON)
                {
                    return 1;
                }
                if(X28==ON)
                {
                    return 2;
                }
                break;
            default:
                break;
        }
        switch (stepmotor->Axis)
        {
            case 0:
                Y10_ON;
                break;
            case 1:
                Y12_ON;
                break;
            case 2:
                Y14_ON;
                break;
            case 3:
                Y16_ON;
                break;
            default:
                break;
        }
        Delay_US(1);
        switch (stepmotor->Axis)
        {
            case 0:
                Y10_OFF;
                break;
            case 1:
                Y12_OFF;
                break;
            case 2:
                Y14_OFF;
                break;
            case 3:
                Y16_OFF;
                break;
            default:
                break;
        }
        Delay_US(80);
        dir == 0?(stepmotor->Position++):(stepmotor->Position--);
    }   
    return 0;
}

// Header: 步进电机定点控制，绝对定位，输入轴号(0-3),脉冲数，
//         输出0，正常，1 正极限，2 负极限
// File Name: 
// Author:
// Date:
char StepMotor_Post(StepMotor *stepmotor,int Plus)
{
    unsigned char dir;
    unsigned int step ,plus = abs((stepmotor->Position)-Plus);
    
    (stepmotor->Position)-Plus>0?(dir = 0):(dir = 1);
    
    //判断方向
    switch (stepmotor->Axis)
    {
        case 0:
            dir ==0?Y9_ON:Y9_OFF;
            break;
        case 1:
            dir ==0?Y11_ON:Y11_OFF;
            break;
        case 2:
            dir ==0?Y13_ON:Y13_OFF;
            break;
        case 3:
            dir ==0?Y15_ON:Y15_OFF;
            break;
        default:
            break;
    }
    
    Delay_US(5);
    //发送脉冲
    for(step=0;step<plus;step++)
    {   
        //极限判断
//        if((X25==ON)||(X27==ON)||(X29==ON)||(X31==ON)) return 1;
//        if((X26==ON)||(X28==ON)||(X30==ON)||(X32==ON)) return 2;
        switch (stepmotor->Axis)
        {
            case 0:
                if(X21==ON)
                {
                    return 1;
                }
                if(X22==ON)
                {
                    return 2;
                }
                break;
            case 1:
                if(X23==ON)
                {
                    return 1;
                }
                if(X24==ON)
                {
                    return 2;
                }
                break;
            case 2:
                if(X25==ON)
                {
                    return 1;
                }
                if(X26==ON)
                {
                    return 2;
                }
                break;
            case 3:
                if(X27==ON)
                {
                    return 1;
                }
                if(X28==ON)
                {
                    return 2;
                }
                break;
            default:
                break;
        }
        switch (stepmotor->Axis)
        {
            case 0:
                Y10_ON;
                break;
            case 1:
                Y12_ON;
                break;
            case 2:
                Y14_ON;
                break;
            case 3:
                Y16_ON;
                break;
            default:
                break;
        }
        Delay_US(1);
        switch (stepmotor->Axis)
        {
            case 0:
                Y10_OFF;
                break;
            case 1:
                Y12_OFF;
                break;
            case 2:
                Y14_OFF;
                break;
            case 3:
                Y16_OFF;
                break;
            default:
                break;
        }
        Delay_US(80);
        dir == 0?(stepmotor->Position++):(stepmotor->Position--);
    }   
    return 0;
}
