#ifndef _STEPMOTOR_H_
#define _STEPMOTOR_H_
#ifdef __cplusplus			//定义对CPP进行C处理
extern "C" {
#endif

#include "Config.h"

/*
TesterStatus {Idle = 0,Busy = 1,Error = 2};
B2BStatus {Idle = 0,connected = 1,Error = 2};
HotbarStatus {Idle = 0,connected = 1,Error = 2};
TOPBondpadsStatus {Idle = 0,connected = 1,Error = 2,aligned = 3};
BOTBondpadsStatus {Idle = 0,connected = 1,Error = 2,aligned = 3};
*/  
typedef struct{
    char Axis ;
    char HomeDIR ;
    int Position ;
}StepMotor;

extern StepMotor CT_M,CB_M,XT_M,XB_M;
    
char StepMotor_Home(StepMotor *stepmotor);
char StepMotor_Control(StepMotor *stepmotor,unsigned char dir,unsigned int Plus);
char StepMotor_Post(StepMotor *stepmotor,int Plus);


#ifdef __cplusplus
}
#endif

#endif
